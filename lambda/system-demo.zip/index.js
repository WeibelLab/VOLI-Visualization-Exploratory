// // cd test-skill-0509
// // rm test-skill-0509.zip
// // zip -r test-skill-0509.zip .
// // Tour: https://developer.amazon.com/en-US/docs/alexa/alexa-skills-kit-sdk-for-nodejs/develop-your-first-skill.html
// // Debug: https://stackoverflow.com/questions/61856434/aws-lambda-function-returning-runtime-handlernotfound-error
// const Alexa = require('ask-sdk-core');
// const helloworldDocument = require('./documents/visualization_background_document.json'); // APL Test
// const HELLO_WORLD_TOKEN = 'helloworldToken'; // APL Test
// const constants = require('./constants'); // constants such as specific service permissions go here



// const LaunchRequestHandler = {
//   canHandle(handlerInput) {
//     return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
//   },
//   handle(handlerInput) {
//     const speechText = 'Welcome, you can ask me to visualize your health. Try saying "How long did I sleep everyday in the past week?"';

//     return handlerInput.responseBuilder
//       .speak(speechText)
//       .reprompt(speechText)
//       .withSimpleCard('Welcome to My Health.', speechText)
//       .getResponse();
//   }
// };



// const AskPictureIntentHandler = {
//   canHandle(handlerInput) {
//     return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
//       && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AskPictureIntent';
//   },
//   handle(handlerInput) {
//     // Original
//     const speechText = 'Welcome to VOLI!';

//     // return handlerInput.responseBuilder
//     //   .speak(speechText)

//     //   .withStandardCard('Visit http://voli.ucsd.edu/', speechText, 
//     //                     'https://yichentest.s3.us-west-2.amazonaws.com/voli-logo-small.png', 
//     //                     'https://yichentest.s3.us-west-2.amazonaws.com/voli-logo-large.png')

//     //   .getResponse();


//     // APL
//     // if (util.supportsAPL(handlerInput)) {
//     //   handlerInput.responseBuilder.addDirective({
//     //     type: 'Alexa.Presentation.APL.RenderDocument',
//     //     version: '1.1',
//     //     document: constants.APL.launchDoc,
//     //     datasources: {
//     //       launchData: {
//     //         type: 'object',
//     //         properties: {
//     //           backgroundImage: util.getS3PreSignedUrl('voli-logo-large.png'),
//     //         },
//     //       }
//     //     }
//     //   });
//     // }
//     // return handlerInput.responseBuilder
//     //   .speak(speechText)
//     //   .getResponse();


//     // Test
//     let speakOutput = 'Hello World!';
//     let responseBuilder = handlerInput.responseBuilder;
//     if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']){
//       // Add the RenderDocument directive to the responseBuilder
//       responseBuilder.addDirective({
//         type: 'Alexa.Presentation.APL.RenderDocument',
//         token: HELLO_WORLD_TOKEN,
//         document: helloworldDocument
//       });
//       // Tailor the speech for a device with a screen.
//       speakOutput += " You should now also see my greeting on the screen."
//     }
//     else {
//       // User's device does not support APL, so tailor the speech to this situation
//       speakOutput += " This example would be more interesting on a device with a screen, such as an Echo Show or Fire TV.";
//     }
//     return responseBuilder
//       .speak(speakOutput)
//       .getResponse();
//   }
// };



// const HelpIntentHandler = {
//   canHandle(handlerInput) {
//     return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
//       && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
//   },
//   handle(handlerInput) {
//     const speechText = 'You can ask me to show the picture!';

//     return handlerInput.responseBuilder
//       .speak(speechText)
//       .reprompt(speechText)
//       .withSimpleCard('You can ask me to show the picture!', speechText)
//       .getResponse();
//   }
// };



// const CancelAndStopIntentHandler = {
//   canHandle(handlerInput) {
//     return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
//       && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
//         || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
//   },
//   handle(handlerInput) {
//     const speechText = 'Goodbye!';

//     return handlerInput.responseBuilder
//       .speak(speechText)
//       .withSimpleCard('Goodbye!', speechText)
//       .withShouldEndSession(true)
//       .getResponse();
//   }
// };



// const SessionEndedRequestHandler = {
//   canHandle(handlerInput) {
//     return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
//   },
//   handle(handlerInput) {
//     // Any clean-up logic goes here.
//     return handlerInput.responseBuilder.getResponse();
//   }
// };



// const ErrorHandler = {
//   canHandle() {
//     return true;
//   },
//   handle(handlerInput, error) {
//     console.log(`Error handled: ${error.message}`);

//     return handlerInput.responseBuilder
//       .speak('Sorry, I don\'t understand your command. Please say it again.')
//       .reprompt('Sorry, I don\'t understand your command. Please say it again.')
//       .getResponse();
//   }
// };



// // Lambda handler
// let skill;
// exports.handler = async function (event, context) {
//   console.log(`REQUEST++++${JSON.stringify(event)}`);
//   if (!skill) {
//     skill = Alexa.SkillBuilders.custom()
//       .addRequestHandlers(
//         LaunchRequestHandler,
//         AskPictureIntentHandler,
//         HelpIntentHandler,
//         CancelAndStopIntentHandler,
//         SessionEndedRequestHandler,
//       )
//       .addErrorHandlers(ErrorHandler)
//       .create();
//   }
//   const response = await skill.invoke(event, context);
//   console.log(`RESPONSE++++${JSON.stringify(response)}`);
//   return response;
// };



// exports.handler = Alexa.SkillBuilders.custom()
//   .addRequestHandlers(
//     LaunchRequestHandler,
//     AskPictureIntentHandler,
//     HelpIntentHandler,
//     CancelAndStopIntentHandler,
//     SessionEndedRequestHandler)
//   .addErrorHandlers(ErrorHandler)
//   .lambda();









const Alexa = require('ask-sdk-core');
const handlers = require('./handlers');
const visualizationBackgroundDocument = require('./documents/visualization_background_document.json'); // APL Test
const constant = require('./constants');

console.log("========== hello world ============");

try {
    exports.handler = Alexa.SkillBuilders.custom()
        .addRequestHandlers(
            handlers.LaunchRequestHandler,
            handlers.AskPictureIntentHandler,
            handlers.HelpIntentHandler,
            handlers.CancelAndStopIntentHandler,
            handlers.SessionEndedHandler)
        .addErrorHandlers(handlers.ErrorHandler)
        .lambda();

} catch (err) {
    console.log("======= building skills =======");
    console.log(err);
}