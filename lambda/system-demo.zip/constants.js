module.exports = {
    APL: {
        launchDoc: require('./documents/launchScreen.json')
    }
}
